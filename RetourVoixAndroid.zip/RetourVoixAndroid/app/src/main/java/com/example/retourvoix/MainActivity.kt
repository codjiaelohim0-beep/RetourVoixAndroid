package com.example.retourvoix

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private val sampleRate = 44100
    private val running = AtomicBoolean(false)
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var wavFile: File? = null
    private var wavOut: BufferedOutputStream? = null
    private var totalPcmBytes = 0L
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var audioManager: AudioManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        status = TextView(this).apply {
            text = "Branche le micro, puis connecte ton casque.\nAppuie sur Démarrer pour entendre ta voix et enregistrer."
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
        }
        startButton = Button(this).apply {
            text = "Démarrer le retour + l’enregistrement"
            setOnClickListener { checkPermissionAndStart() }
        }
        stopButton = Button(this).apply {
            text = "Arrêter et sauvegarder"
            isEnabled = false
            setOnClickListener { stopMonitoring(true) }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 32, 20, 32)
            addView(status, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(startButton, LinearLayout.LayoutParams(-1, -2))
            addView(stopButton, LinearLayout.LayoutParams(-1, -2))
        }
        setContentView(layout)
    }

    private fun checkPermissionAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 20)
        } else {
            startMonitoring()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startMonitoring()
        } else {
            status.text = "L’autorisation du micro est nécessaire."
        }
    }

    private fun startMonitoring() {
        if (running.get()) return
        val minIn = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val minOut = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minIn <= 0 || minOut <= 0) {
            status.text = "Ce téléphone ne prend pas en charge le format audio demandé."
            return
        }

        try {
            val inputBuffer = maxOf(minIn, 4096) * 2
            val outputBuffer = maxOf(minOut, 4096) * 2
            recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, inputBuffer
            )
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val format = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            player = AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(format)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(outputBuffer)
                .build()

            val dir = getExternalFilesDir(null) ?: filesDir
            wavFile = File(dir, "RetourVoix_${System.currentTimeMillis()}.wav")
            wavOut = BufferedOutputStream(FileOutputStream(wavFile!!))
            wavOut!!.write(ByteArray(44)) // WAV header filled in on stop
            totalPcmBytes = 0

            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Let Android choose the current communication output (often the Bluetooth headset).
                // Bluetooth routing varies by phone and headset.
                val devices = audioManager.availableCommunicationDevices
                val bt = devices.firstOrNull {
                    it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                }
                if (bt != null) audioManager.setCommunicationDevice(bt)
            } else {
                @Suppress("DEPRECATION")
                audioManager.startBluetoothSco()
                @Suppress("DEPRECATION")
                audioManager.isBluetoothScoOn = true
            }

            recorder!!.startRecording()
            player!!.play()
            running.set(true)
            startButton.isEnabled = false
            stopButton.isEnabled = true
            status.text = "Retour audio actif.\nParle dans le micro. Le fichier sera sauvegardé quand tu arrêteras."
            worker = Thread {
                val buffer = ShortArray(1024)
                try {
                    while (running.get()) {
                        val count = recorder?.read(buffer, 0, buffer.size) ?: 0
                        if (count > 0) {
                            player?.write(buffer, 0, count, AudioTrack.WRITE_BLOCKING)
                            val bytes = ByteArray(count * 2)
                            for (i in 0 until count) {
                                val v = buffer[i].toInt()
                                bytes[i * 2] = (v and 0xff).toByte()
                                bytes[i * 2 + 1] = ((v shr 8) and 0xff).toByte()
                            }
                            synchronized(this) {
                                wavOut?.write(bytes)
                                totalPcmBytes += bytes.size
                            }
                        }
                    }
                } catch (_: Exception) {
                    runOnUiThread { status.text = "Le flux audio s’est interrompu. Appuie sur Arrêter." }
                }
            }.also { it.start() }
        } catch (e: Exception) {
            stopMonitoring(false)
            status.text = "Impossible de démarrer l’audio sur ce téléphone : ${e.message ?: "erreur audio"}"
        }
    }

    private fun stopMonitoring(showSaved: Boolean) {
        running.set(false)
        try { worker?.join(500) } catch (_: Exception) {}
        worker = null
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { player?.pause(); player?.flush(); player?.stop(); player?.release() } catch (_: Exception) {}
        player = null

        try {
            synchronized(this) {
                wavOut?.flush()
                wavOut?.close()
                wavOut = null
                wavFile?.let { writeWavHeader(it, totalPcmBytes) }
            }
        } catch (_: Exception) {}

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try { audioManager.clearCommunicationDevice() } catch (_: Exception) {}
        } else {
            @Suppress("DEPRECATION")
            audioManager.stopBluetoothSco()
            @Suppress("DEPRECATION")
            audioManager.isBluetoothScoOn = false
        }
        audioManager.mode = AudioManager.MODE_NORMAL
        startButton.isEnabled = true
        stopButton.isEnabled = false
        val file = wavFile
        status.text = if (showSaved && file != null && file.exists()) {
            "Enregistrement sauvegardé dans :\n${file.absolutePath}"
        } else {
            "Prêt. Branche le micro et connecte ton casque."
        }
        if (showSaved && file != null) {
            Toast.makeText(this, "Audio sauvegardé dans le dossier de l’application", Toast.LENGTH_LONG).show()
        }
    }

    private fun writeWavHeader(file: File, pcmBytes: Long) {
        RandomAccessFile(file, "rw").use { raf ->
            raf.seek(0)
            val header = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray(Charsets.US_ASCII))
            header.putInt((36 + pcmBytes).toInt())
            header.put("WAVE".toByteArray(Charsets.US_ASCII))
            header.put("fmt ".toByteArray(Charsets.US_ASCII))
            header.putInt(16)
            header.putShort(1.toShort())
            header.putShort(1.toShort())
            header.putInt(sampleRate)
            header.putInt(sampleRate * 2)
            header.putShort(2.toShort())
            header.putShort(16.toShort())
            header.put("data".toByteArray(Charsets.US_ASCII))
            header.putInt(pcmBytes.toInt())
            raf.write(header.array())
        }
    }

    override fun onDestroy() {
        stopMonitoring(false)
        super.onDestroy()
    }
}
