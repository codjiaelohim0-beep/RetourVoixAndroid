RETOUR DE VOIX — prototype Android

Ce projet est le code source d'une petite application Android qui :
- prend le son du micro sélectionné par Android ;
- renvoie le son en direct vers la sortie audio choisie par Android ;
- enregistre en même temps un fichier WAV.

IMPORTANT
- C'est un prototype, pas un APK déjà installé.
- Il faut ouvrir le projet dans Android Studio puis le compiler pour obtenir un APK.
- Le routage du Bluetooth dépend du téléphone et du casque. Android peut choisir le micro du casque Bluetooth au lieu du micro externe.
- Le Bluetooth peut provoquer un retard audible. Un casque filaire donne généralement un retour plus rapide.
- Le fichier est sauvegardé dans le dossier privé de l'application (getExternalFilesDir). L'écran affiche le chemin après l'arrêt.
- Pour un test, commence à faible volume afin d'éviter le larsen.

POUR CRÉER L'APK
1. Installe Android Studio sur un ordinateur.
2. Décompresse RetourVoixAndroid.zip.
3. Dans Android Studio, choisis Open et sélectionne le dossier RetourVoixAndroid.
4. Attends la synchronisation Gradle.
5. Connecte ton téléphone Android par USB et active les options développeur + débogage USB, ou utilise Build > Build APK(s).
6. Dans Build > Build APK(s), Android Studio créera l'APK.

UTILISATION
1. Branche le micro au téléphone.
2. Connecte le casque Bluetooth.
3. Ouvre « Retour de voix » et autorise le micro.
4. Appuie sur « Démarrer le retour + l’enregistrement ».
5. Parle : la voix est renvoyée vers la sortie audio sélectionnée et enregistrée.
6. Appuie sur « Arrêter et sauvegarder ».

Si le son ne revient pas dans le casque, le téléphone ou le casque peut ne pas accepter cette combinaison de routage. Essaie avec des écouteurs filaires ou un casque USB-C.
